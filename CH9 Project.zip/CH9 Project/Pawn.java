public class Pawn extends ChessPiece{

//    String[][] ChessBoard = { {"A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1"},
//                              {"A2" Pawn, "B2" Pawn, "C2" Pawn, "D2" Pawn, "E2" Pawn, "F2" Pawn, "G2" Pawn, "H2" Pawn},
//                              {"A3", "B3", "C3", "D3", "E3", "F3", "G3", "H3"},
//                              {"A4", "B4", "C4", "D4", "E4", "F4", "G4", "H4"},
//                              {"A5", "B5", "C5", "D5", "E5", "F5", "G5", "H5"},
//                              {"A6", "B6", "C6", "D6", "E6", "F6", "G6", "H6"},
//                              {"A7" Pawn, "B7" Pawn, "C7" Pawn, "D7" Pawn, "E7" Pawn, "F7" Pawn, "G7" Pawn, "H7" Pawn},
//                              {"A8", "B8", "C8", "D8", "E8", "F8", "G8", "H8"},
//                            };
    ArrayList<String> ChessBoard = new ArrayList<String>();
    Pawn(){
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
    ChessBoard.add(Pawn);
  }
}
