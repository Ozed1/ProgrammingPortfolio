import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int[][] arr = { { } }

  }
}
