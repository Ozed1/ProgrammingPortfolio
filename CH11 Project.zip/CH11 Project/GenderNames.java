import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files
import java.io.IOException;

public class GenderNames {
  public static void main(String[] args) {
    try {
      File boysNames = new File("boysNames.txt");
      Scanner myReader = new Scanner(boysNames);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    try {
      File girlsNames = new File("girlsNames.txt");
      Scanner myReader1 = new Scanner(girlsNames);
      while (myReader1.hasNextLine()) {
        String data1 = myReader1.nextLine();
        System.out.println(data1);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}
