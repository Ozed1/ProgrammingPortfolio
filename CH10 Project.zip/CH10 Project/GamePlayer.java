class GamePlayer implements Game {
  String Game;
  boolean isValidMove(String move);

  public void move() {
    System.out.println("Please make a move:");
  }
  public void executeMove() {
    System.out.println("Updating the Board.");
  }
}
