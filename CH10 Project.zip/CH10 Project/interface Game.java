interface Game{
    public move{

  }
    public executeMove{

  }
    public updateBoard{

  }
}
