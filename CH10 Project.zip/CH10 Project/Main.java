class Main {
  public static void Main(String[] args) {
    GamePlayer newGame = new GamePlayer();
    newGame.move();
    newGame.executeMove();
  }
}
