import java.util.*;

public class CH8Program {
  private int secret1, secret2, secret3;
  secret1 = 14;
  secret2 = 18;
  secret3 = 36;
  public int guesssecret1, guesssecret2, guesssecret3;
  public int dial = 0;
  public static void Main(String[] args){

    public ComboLock(int secret1, int secret2, int secret3) {
      this.secret1 = secret1;
      this.secret2 = secret2;
      this.secret3 = secret3;
    }
    public void reset() {
      secret1 = 0;
      secret2 = 0;
      secret3 = 0;
    }
    public void turnLeft2(int ticks) {
      dial = (dial + ticks) % 40;
      guesssecret2 = dial;
    }
    public void turnRight1(int ticks) {
      dial = (dial - ticks + 40) % 40;
      guesssecret1 = dial;
    }
    public void turnRight3(int ticks) {
      dial = (dial - ticks + 40) % 40;
      guesssecret3 = dial;
    }
    public boolean open() {
      if(guesssecret1 == secret1 && guesssecret2 == secret2 && guesssecret3 == secret3){
        open == true;
      }
    }



 }
]
